from setuptools import setup

setup(name="Package_Housing",
version="0.1",
description="Housing Project Assignment 2.1",
long_description="Need to set it up as a package",
author="Radha",
packages=['Package_Housing'],
#package_dir={'':'Package_Housing'},
install_requires=[])
