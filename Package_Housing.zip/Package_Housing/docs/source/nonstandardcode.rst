nonstandardcode module
======================

.. automodule:: nonstandardcode
   :members:
   :undoc-members:
   :show-inheritance:
